<?php
 var_dump($rifas);
 