<?php

function EnviarWhatsapp(int $numero, string $boletos)
{
   echo "Boletos Apartados Exitosamente";
}